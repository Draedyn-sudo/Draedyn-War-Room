Chronicles of Draedyn: GitHub Pages website

1. Sign into github.com and create a new PUBLIC repository, for example draedyn-war-room.
2. Choose Add file > Upload files and upload index.html from this folder.
3. Commit changes.
4. In repository Settings > Pages, choose Deploy from a branch, main, /(root), Save.
5. Wait for GitHub Pages to publish the URL shown on that settings page.
6. Open the published HTTPS address in Safari. Use Share > Add to Home Screen.

Campaign saves are local to the browser/device. They do not sync between devices.
Back up your data before clearing website data.
